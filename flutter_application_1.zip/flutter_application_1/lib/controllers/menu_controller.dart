import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/menu.dart';
// Variabel observable (obs) agar UI otomatis update saat isi list berubah
class MenuuController extends GetxController {
  var menuList = <Menu>[].obs;
  final String apiUrl = 'http://service2310020101.test/api/menus';// Alamat endpoint API

  @override
  void onInit() {
    super.onInit();
    tangkapDataMenu(); // Memanggil fungsi fetch data secara otomatis saat controller pertama kali dimuat
  }
  // READ: Mengambil data dari API
  Future<void> tangkapDataMenu() async {
    final response = await http.get(Uri.parse(apiUrl));
    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);// Mengubah list JSON menjadi list objek Menu dan memasukkannya ke menuList
      menuList.value = data.map((item) =>
          Menu.fromJson(item)).toList();
    } else {
      Exception('Gagal Ambil Data menu');
    }
  }
  // CREATE: Menambah data menu baru ke API
  Future<void> addMenu(Menu menu) async {
    final response = await http.post(Uri.parse(apiUrl),
      headers: {"Content-Type": "application/json"},
      body: json.encode(menu.toJson()));

    if (response.statusCode == 201) { // Jika berhasil, tambahkan data baru tersebut ke list lokal agar UI terupdate
      menuList.add(Menu.fromJson(json.decode(response.body)));
    } else {
      throw Exception('Gagal Simpan Data menu');
    }
  }
  // UPDATE: Mengubah data menu yang sudah ada berdasarkan ID
  Future<void> updateMenu(int id, Menu menu) async {
    final response = await http.put(
      Uri.parse('$apiUrl/$id'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(menu.toJson()),
    );

    if (response.statusCode == 200) { // Cari index menu di list lokal, lalu ganti dengan data terbaru dari API
      final index = menuList.indexWhere((m) => m.id == menu.id);
      if (index != -1) {
        menuList[index] = Menu.fromJson(json.decode(response.body));
      }
    } else {
      throw Exception('Gagal update menu');
    }
  }
  // DELETE: Menghapus data menu berdasarkan ID
  Future<void> deleteMenu(int id) async {
    final response = await http.delete(Uri.parse('$apiUrl/$id'));
    if (response.statusCode == 204) { // Jika berhasil di API, hapus juga dari list lokal
      menuList.removeWhere((m) => m.id == id);
    } else {
      throw Exception('Gagal Hapus Data menu');
    }
  }
}