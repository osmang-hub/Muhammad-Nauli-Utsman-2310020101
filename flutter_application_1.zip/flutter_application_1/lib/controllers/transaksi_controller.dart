import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/transaksi_model.dart';

class TransaksiController extends GetxController {
  var transaksiList = <Transaksi>[].obs;
  final String apiUrl = 'http://service2310020101.test/api/transaksis';

  @override
  void onInit() {
    super.onInit();
    tangkapTransaksi();
  }

  Future<void> tangkapTransaksi() async {
      final response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        transaksiList.value = data.map((item) =>
Transaksi.fromJson(item)).toList();
      } else {
        Exception('Gagal Ambil data Transaksi');
      }
  }

  Future <void> addTransaksi(Transaksi transaksi) async {
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(transaksi.toJson()),
    );

    if (response.statusCode == 201) {
      transaksiList.add(Transaksi.fromJson(json.decode(response.body)));
    } else {
      throw Exception('Gagal simpan transaksi');
    }
  } 

  Future<void> updateTransaksi(int id_transaksi, Transaksi transaksi) async {
    final response = await http.put(
      Uri.parse('$apiUrl/$id_transaksi'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(transaksi.toJson()),
    );

    if (response.statusCode == 200) {
      final index = transaksiList.indexWhere((t) => t.id_transaksi == transaksi.id_transaksi);
      if (index != -1) {
        transaksiList[index] = Transaksi.fromJson(json.decode(response.body));
      }
    } else {
      throw Exception('Gagal update transaksi');
    }
  }

  Future<void> deleteTransaksi(int id_transaksi) async {
    final response = await http.delete(
      Uri.parse('$apiUrl/$id_transaksi'),
    );

    if (response.statusCode == 204) {
      transaksiList.removeWhere((t) => t.id_transaksi == id_transaksi);
    } else {
      throw Exception('Gagal hapus transaksi');
    }
  }

}