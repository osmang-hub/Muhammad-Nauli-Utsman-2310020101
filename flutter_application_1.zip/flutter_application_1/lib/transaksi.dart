// Legacy/duplicate model renamed to avoid conflicts with models/transaksi_model.dart
class TransaksiLegacy {
  final int id_transaksi;
  final int total_transaksi;
  final int total_bayar;
  final int total_kembali;

  TransaksiLegacy({
    required this.id_transaksi,
    required this.total_transaksi,
    required this.total_bayar,
    required this.total_kembali,
  });

  factory TransaksiLegacy.fromJson(Map<String, dynamic> json) {
    return TransaksiLegacy(
      id_transaksi: json['id_transaksi'],
      total_transaksi: json['total_transaksi'],
      total_bayar: json['total_bayar'],
      total_kembali: json['total_kembali'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id_transaksi': id_transaksi,
      'total_transaksi': total_transaksi,
      'total_bayar': total_bayar,
      'total_kembali': total_kembali,
    };
  }
}