import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/transaksi_controller.dart';
import '../models/transaksi_model.dart';

class TransaksiView extends StatelessWidget {
  TransaksiView({super.key});
  final TransaksiController transaksiController = Get.put(TransaksiController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Transaksi'),
      ),
      body: Obx(() {
        final list = transaksiController.transaksiList;
        if (list.isEmpty) {
          return const Center(child: Text('Tidak ada data transaksi'));
        }

        return ListView.builder(
          itemCount: list.length,
          itemBuilder: (context, index) {
            final Transaksi transaksi = list[index];
            return Card(
              margin: const EdgeInsets.all(10),
              elevation: 5,
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      transaksi.id_transaksi.toString(),
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 5),
                    Text('Total Transaksi: ${transaksi.total_transaksi}'),
                    Text('Total Bayar: ${transaksi.total_bayar}'),
                    Text('Total Kembali: ${transaksi.total_kembali}'),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: <Widget>[
                        TextButton(
                          child: const Text('Hapus'),
                          onPressed: () {
                            transaksiController.deleteTransaksi(transaksi.id_transaksi);
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      }),
    );
  }
}

                      
                    

                      