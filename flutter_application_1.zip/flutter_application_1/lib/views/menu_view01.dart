import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/menu_controller.dart';
import 'tambah_menu.dart';
import 'ubah_menu.dart';

class MenuView01 extends StatelessWidget { // Menghubungkan View dengan Controller
  final MenuuController controller = Get.put(MenuuController());

  MenuView01({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Menu'),
      ),
      body: Column(
        children: [
          Expanded( // Obx digunakan untuk memantau perubahan pada menuList di controller
            child: Obx(() {
              if (controller.menuList.isEmpty) {
                return Center(child: Text('Tidak ada data menu tersedia.'));
              }
              return ListView.builder(
                itemCount: controller.menuList.length,
                itemBuilder: (context, index) {
                  final menu = controller.menuList[index];
                  return Card( // ... kode UI Card ...
                    margin: const EdgeInsets.all(10),
                    elevation: 5,
                    child: Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Row(
                        children: [ // Menampilkan informasi detail menu
                          Expanded( 
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  menu.nama_menu,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text('ID Menu: ${menu.id_menu}'),
                                Text('Nama Menu: ${menu.nama_menu}'),
                                Text('Harga Menu: \$${menu.harga_menu.toStringAsFixed(2)}'),
                                Text('Status Menu: ${menu.status_menu}'),
                                Text('Pupuk: ${menu.pupuk}'),
                                Text('Jumlah: ${menu.jumlah}'),
                                Text('Tanggal: ${menu.tanggal}'),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.edit),
                            onPressed: () {
                              Get.to(() => EditMenuView(menu: menu));
                            },
                          ),
                          IconButton( // Tombol Hapus
                            icon: const Icon(Icons.delete),
                            onPressed: () {
                              controller.deleteMenu(menu.id);
                            },
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            }),
          ),
          ElevatedButton( // Tombol melayang untuk menambah menu baru
            onPressed: () {
              Get.to(() => TambahMenuView());
            },
            child: const Text('Tambah Menu'),
          ),
        ],
      ),
    );
  }
}
