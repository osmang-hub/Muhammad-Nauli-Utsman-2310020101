import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/transaksi_controller.dart';
import '../models/transaksi_model.dart';
import 'tambah_transaksi.dart';
import 'ubah_transaksi.dart';
class TransaksiView extends StatelessWidget {
  final TransaksiController controller = Get.put(TransaksiController());

TransaksiView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Transaksi'), 
      ),
      body: Obx(() {
        if (controller.transaksiList.isEmpty) {
          return const Center(child: Text('Tidak ada data transaksi'));
        }

        return ListView.builder(
          itemCount: controller.transaksiList.length,
          itemBuilder: (context, index) {
            final Transaksi transaksi = controller.transaksiList[index];
            return Card(
              margin: const EdgeInsets.all(10),
              elevation: 5,
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Row(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundImage: NetworkImage(
                      'https://service2310020101.test/storage/images/${transaksi.id_transaksi}.jpg'),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'ID: ${transaksi.id_transaksi}',
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        Text("Total Transaksi: ${transaksi.total_transaksi}"),
                        Text("Total Bayar: ${transaksi.total_bayar}"),
                        Text("Total Kembali: ${transaksi.total_kembali}"),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () {
                      Get.to(() => EditTransaksiView(transaksi: transaksi));
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () {
                      controller.deleteTransaksi(transaksi.id_transaksi);
                    },
                  ),
                ],
              ),
              ),
            );
          },
        );
      }),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Get.to(() => TambahTransaksiView());
        },
        label: const Text('Tambah Transaksi'),
        icon: const Icon(Icons.add),
      ),
    );
  }
}
