import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/menu_controller.dart';
import '../models/menu.dart';

class TambahMenuView extends StatelessWidget { // Menghubungkan ke controller yang sudah ada atau membuat baru
  final MenuuController menuController = Get.put(MenuuController());
  // Kontroler untuk menangkap input teks dari masing-masing field
  final TextEditingController idMenuController = TextEditingController();
  final TextEditingController namaMenuController = TextEditingController();
  final TextEditingController hargaMenuController = TextEditingController();
  final TextEditingController statusMenuController = TextEditingController();
  final TextEditingController pupukController = TextEditingController();
  final TextEditingController jumlahController = TextEditingController();
  final TextEditingController tanggalController = TextEditingController();

  TambahMenuView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tambah Menu'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [ // Input field untuk data string
            TextField(
              controller: idMenuController,
              decoration: const InputDecoration(labelText: 'ID Menu'),
            ),
            TextField(
              controller: namaMenuController,
              decoration: const InputDecoration(labelText: 'Nama Menu'),
            ),
            TextField( // Input field khusus angka menggunakan keyboardType number
              controller: hargaMenuController,
              decoration: const InputDecoration(labelText: 'Harga Menu'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: statusMenuController,
              decoration: const InputDecoration(labelText: 'Status Menu'),
            ),
            TextField(
              controller: pupukController,
              decoration: const InputDecoration(labelText: 'Pupuk'),
            ),
            TextField(
              controller: jumlahController,
              decoration: const InputDecoration(labelText: 'Jumlah'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: tanggalController,
              decoration: const InputDecoration(labelText: 'Tanggal'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () { // Membuat objek Menu baru dari input user
                final menu = Menu(
                  id: 0, //  ID diabaikan karena akan digenerate oleh database server
                  id_menu: idMenuController.text,
                  nama_menu: namaMenuController.text,
                  harga_menu: double.tryParse(hargaMenuController.text) ?? 0.0, // Mengonversi string ke double dengan nilai default 0.0 jika input tidak valid
                  status_menu: statusMenuController.text,
                  pupuk: pupukController.text,
                  jumlah: double.tryParse(jumlahController.text) ?? 0.0,
                  tanggal: tanggalController.text,
                ); // Memanggil fungsi addMenu di controller dan kembali ke halaman utama
                menuController.addMenu(menu);
                Get.back(); // Kembali ke halaman menu
              },
              child: const Text('Simpan '),
            ),
          ],
        ),
      ),
    );
  }
}