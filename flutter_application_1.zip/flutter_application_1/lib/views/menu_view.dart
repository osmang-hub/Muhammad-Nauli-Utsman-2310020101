import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/menu_controller.dart' as mc;
class MenuView extends StatelessWidget {
  MenuView({super.key});
  final mc.MenuController menuController = Get.put(mc.MenuController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Data Menu'),
      ),
      body: Column(
        children: [
          Expanded(
            child: Obx(() {
              if (menuController.menuList.isEmpty) {
                return Center(child: Text('Tidak ada data menu tersedia.'));
              }
              return ListView.builder(
                itemCount: menuController.menuList.length,
                itemBuilder: (context, index) {
                  final menu = menuController.menuList[index];
                  return Card(
                    margin: EdgeInsets.all(10),
                    elevation: 5,
                    child: Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Nama Menu: ${menu.nama_menu}',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text('Harga Menu: \$${menu.harga_menu.toStringAsFixed(2)}'),
                          SizedBox(height: 8),
                          Text('Status Menu: ${menu.status_menu}'),
                          SizedBox(height: 8),
                          Text('Pupuk: ${menu.pupuk}'),
                          SizedBox(height: 8),
                          Text('Jumlah: ${menu.jumlah}'),
                          SizedBox(height: 8),
                          Text('Tanggal: ${menu.tanggal}'),
                          SizedBox(height: 10),
                          OverflowBar(
                            alignment: MainAxisAlignment.end,
                            children: <Widget>[
                              TextButton(
                                onPressed: () {
                                  // Implement edit functionality
                                },
                                child: Text('Edit'),
                              ),
                              TextButton(
                                onPressed: () {
                                  menuController.deleteMenu(menu.id);
                                },
                                child: Text('Hapus'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            }),
          ),
        ],
      ),
    );
  }
}



