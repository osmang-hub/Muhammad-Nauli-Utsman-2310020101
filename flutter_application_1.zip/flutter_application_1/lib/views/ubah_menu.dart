import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/menu_controller.dart';
import '../models/menu.dart';

class EditMenuView extends StatefulWidget { // Menerima data menu yang dipilih dari halaman daftar
  final Menu menu;

  EditMenuView({required this.menu});

  @override
  _EditMenuViewState createState() => _EditMenuViewState();
}

class _EditMenuViewState extends State<EditMenuView> {
  final MenuuController controller = Get.put(MenuuController());
  // Inisialisasi controller teks
  final TextEditingController idMenuController = TextEditingController();
  final TextEditingController namaMenuController = TextEditingController();
  final TextEditingController hargaMenuController = TextEditingController();
  final TextEditingController statusMenuController = TextEditingController();
  final TextEditingController pupukController = TextEditingController();
  final TextEditingController jumlahController = TextEditingController();
  final TextEditingController tanggalController = TextEditingController();

  @override
  void initState() {
    super.initState(); // Mengisi TextField dengan data menu yang sudah ada (Initial Value)
    idMenuController.text = widget.menu.id_menu;
    namaMenuController.text = widget.menu.nama_menu;
    hargaMenuController.text = widget.menu.harga_menu.toString();
    statusMenuController.text = widget.menu.status_menu;
    pupukController.text = widget.menu.pupuk;
    jumlahController.text = widget.menu.jumlah.toString();
    tanggalController.text = widget.menu.tanggal;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Menu'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: idMenuController,
                decoration: InputDecoration(labelText: 'ID Menu'),
              ),
              TextField(
                controller: namaMenuController,
                decoration: InputDecoration(labelText: 'Nama Menu'),
              ),
              TextField(
                controller: hargaMenuController,
                decoration: InputDecoration(labelText: 'Harga Menu'),
              ),
              TextField(
                controller: statusMenuController,
                decoration: InputDecoration(labelText: 'Status Menu'),
              ),
              TextField(
                controller: pupukController,
                decoration: InputDecoration(labelText: 'Pupuk'),
              ),
              TextField(
                controller: jumlahController,
                decoration: InputDecoration(labelText: 'Jumlah'),
              ),
              TextField(
                controller: tanggalController,
                decoration: InputDecoration(labelText: 'Tanggal'),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () { // Membuat objek Menu baru berisi data hasil update
                  final updatedMenu = Menu(
                    id: widget.menu.id, // Tetap menggunakan ID database asli
                    id_menu: idMenuController.text,
                    nama_menu: namaMenuController.text,
                    harga_menu: double.parse(hargaMenuController.text),
                    status_menu: statusMenuController.text,
                    pupuk: pupukController.text,
                    jumlah: double.parse(jumlahController.text),
                    tanggal: tanggalController.text,
                  ); // Mengirim data ke API melalui controller
                  controller.updateMenu(widget.menu.id!, updatedMenu);
                  Get.back(); // Kembali ke halaman utama
                },
                child: Text('Simpan Perubahan'),
              ),
            ],
          ),
        ),
      ),    );
  }
}