import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/transaksi_controller.dart';
import '../models/transaksi_model.dart';

class EditTransaksiView extends StatefulWidget {
  final Transaksi transaksi;

  const EditTransaksiView({ required this.transaksi});

  @override
  _EditTransaksiViewState createState() => _EditTransaksiViewState();
}

class _EditTransaksiViewState extends State<EditTransaksiView> {
  final TransaksiController controller = Get.find();

  final TextEditingController totalTransaksiController = TextEditingController();
  final TextEditingController totalBayarController = TextEditingController();
  final TextEditingController totalKembaliController = TextEditingController();

  @override
  void initState() {
    super.initState();
    totalTransaksiController.text = widget.transaksi.total_transaksi.toString();
    totalBayarController.text = widget.transaksi.total_bayar.toString();
    totalKembaliController.text = widget.transaksi.total_kembali.toString();
  }

  @override
  void dispose() {
    totalTransaksiController.dispose();
    totalBayarController.dispose();
    totalKembaliController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ubah Transaksi'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: totalTransaksiController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Total Transaksi'),
              ),
              TextField(
                controller: totalBayarController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Total Bayar'),
              ),
              TextField(
                controller: totalKembaliController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Total Kembali'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  final double totalTransaksi = double.tryParse(totalTransaksiController.text) ?? 0.0;
                  final double totalBayar = double.tryParse(totalBayarController.text) ?? 0.0;
                  final double totalKembali = double.tryParse(totalKembaliController.text) ?? 0.0;

                  final updatedTransaksi = Transaksi(
                    id_transaksi: widget.transaksi.id_transaksi,
                    total_transaksi: totalTransaksi,
                    total_bayar: totalBayar,
                    total_kembali: totalKembali,
                  );

                  controller.updateTransaksi(widget.transaksi.id_transaksi, updatedTransaksi).then((_) {
                    Get.back();
                  });
                },
                child: const Text('Simpan Perubahan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
