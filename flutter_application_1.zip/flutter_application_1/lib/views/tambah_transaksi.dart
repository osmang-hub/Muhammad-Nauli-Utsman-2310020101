import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/transaksi_controller.dart';
import '../models/transaksi_model.dart';

class TambahTransaksiView extends StatelessWidget {
  final TransaksiController controller = Get.find();

  final TextEditingController totalTransaksiController = TextEditingController();
  final TextEditingController totalBayarController = TextEditingController();
  final TextEditingController totalKembaliController = TextEditingController();

TambahTransaksiView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tambah Transaksi'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: totalTransaksiController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Total Transaksi'),
            ),
            TextField(
              controller: totalBayarController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Total Bayar'),
            ),
            TextField(
              controller: totalKembaliController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Total Kembali'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                final double totalTransaksi = double.tryParse(totalTransaksiController.text) ?? 0.0;
                final double totalBayar = double.tryParse(totalBayarController.text) ?? 0.0;
                final double totalKembali = double.tryParse(totalKembaliController.text) ?? 0.0;

                final newTransaksi = Transaksi(
                  id_transaksi: 0, // ID will be set by the server
                  total_transaksi: totalTransaksi,
                  total_bayar: totalBayar,
                  total_kembali: totalKembali,
                );

                controller.addTransaksi(newTransaksi).then((_) {
                  Get.back();
                });
              },
              child: Text('Simpan Transaksi'),
            ),
          ],
        ),
      ),
    );
  }
}
