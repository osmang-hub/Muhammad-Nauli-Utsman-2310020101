class Menu {
  final int id;
  final String id_menu;
  final String nama_menu;
  final double harga_menu;
  final String status_menu;
  final String pupuk;
  final double jumlah;
  final String tanggal;
// Constructor untuk membuat objek Menu
  Menu({
    required this.id,
    required this.id_menu,
    required this.nama_menu,
    required this.harga_menu,
    required this.status_menu,
    required this.pupuk,
    required this.jumlah,
    required this.tanggal,
  });
// Factory method untuk mengubah data JSON dari API menjadi objek Menu (Mapping)
  factory Menu.fromJson(Map<String, dynamic> json) {
    return Menu(
      id: json['id'],
      id_menu: json['id_menu'],
      nama_menu: json['nama_menu'],
      harga_menu: json['harga_menu'],
      status_menu: json['status_menu'],
      pupuk: json['pupuk'],
      jumlah: json['jumlah'],
      tanggal: json['tanggal'],
    );
  }
// Method untuk mengubah objek Menu menjadi JSON sebelum dikirim ke API
  Map<String, dynamic> toJson() {
    return {
      'id_menu': id_menu,
      'nama_menu': nama_menu,
      'harga_menu': harga_menu,
      'status_menu': status_menu,
      'pupuk': pupuk,
      'jumlah': jumlah,
      'tanggal': tanggal,
    };
  }
}