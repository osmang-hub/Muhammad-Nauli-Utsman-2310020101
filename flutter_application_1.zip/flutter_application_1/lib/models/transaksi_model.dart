class Transaksi {
  int id_transaksi;
  double total_transaksi;
  double total_bayar;
  double total_kembali;

  Transaksi({
    required this.id_transaksi,
    required this.total_transaksi,
    required this.total_bayar,
    required this.total_kembali,
  });

  factory Transaksi.fromJson(Map<String, dynamic> json) {
    double parseDouble(dynamic v) {
      if (v == null) return 0.0;
      if (v is double) return v;
      if (v is int) return v.toDouble();
      if (v is String) return double.tryParse(v) ?? 0.0;
      return 0.0;
    }

    return Transaksi(
      id_transaksi: json['id_transaksi'] is int
          ? json['id_transaksi']
          : int.tryParse(json['id_transaksi'].toString()) ?? 0,
      total_transaksi: parseDouble(json['total_transaksi']),
      total_bayar: parseDouble(json['total_bayar']),
      total_kembali: parseDouble(json['total_kembali']),
    );
  }

  Map<String, dynamic> toJson() => {
        'id_transaksi': id_transaksi,
        'total_transaksi': total_transaksi,
        'total_bayar': total_bayar,
        'total_kembali': total_kembali,
      };
}
